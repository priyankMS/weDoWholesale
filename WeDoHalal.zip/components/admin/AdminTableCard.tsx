import type { ReactNode } from "react";

// Shared wrapper for every admin data table. Caps the table's own height
// and scrolls internally (both axes) with a sticky header, so a long list
// (e.g. 166 products) scrolls in place instead of growing the whole page —
// the sidebar and page filters stay put. Colors match the mockup's
// .table-wrap/thead so every table across the admin renders identically.
export function AdminTableCard({ children }: { children: ReactNode }) {
  return (
    <div className="max-h-[calc(100vh-360px)] overflow-auto rounded-md border border-[#e4e1dc] bg-white sm:max-h-[calc(100vh-260px)] [&_thead]:sticky [&_thead]:top-0 [&_thead]:z-10 [&_thead>tr]:bg-[#f0ede9]">
      {children}
    </div>
  );
}
