export { welcomeEmail, type WelcomeEmailParams } from "@/lib/email/templates/welcome";
export {
  orderConfirmationEmail,
  type OrderConfirmationParams,
  type OrderConfirmationLineItem,
} from "@/lib/email/templates/orderConfirmation";
export { orderDispatchedEmail, type OrderDispatchedParams } from "@/lib/email/templates/orderDispatched";
export {
  orderSubstitutionEmail,
  type OrderSubstitutionParams,
} from "@/lib/email/templates/orderSubstitution";
export {
  orderRevisedEmail,
  type OrderRevisedParams,
} from "@/lib/email/templates/orderRevised";
export { invoiceEmail, type InvoiceEmailParams } from "@/lib/email/templates/invoice";
export { passwordResetEmail, type PasswordResetEmailParams } from "@/lib/email/templates/passwordReset";
export {
  adminPasswordResetEmail,
  type AdminPasswordResetEmailParams,
} from "@/lib/email/templates/adminPasswordReset";
export { lowStockAlertEmail, type LowStockAlertParams } from "@/lib/email/templates/lowStockAlert";
